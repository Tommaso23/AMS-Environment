﻿using System.Text.Json.Serialization;
using Newtonsoft.Json;
namespace MediaServicesWebApp.Models;

public class EncoderPreset
{
    public required string Id {get; set;}

    public required string Name {get; set;}

    public required string Description {get; set;}

    public required string PresetParameters {get;set;}
}


