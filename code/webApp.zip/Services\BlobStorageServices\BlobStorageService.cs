﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.Extensions.Logging;


namespace MediaServicesWebApp.Services.BlobStorageServices;

public class BlobStorageService : IBlobStorageService
{
    private readonly IConfiguration _configuration;
    private readonly ILogger<BlobStorageService> _logger;

    private string _encoderassetsStorageConnectionString;

    private string _encoderassetsStorageContainerName;



    public BlobStorageService(IConfiguration configuration, ILogger<BlobStorageService> logger)
    {
        _configuration = configuration;
        _logger = logger;
        _encoderassetsStorageConnectionString = _configuration.GetValue<string>("WEBSITE_ENCODERASSETSSTORAGECONNECTIONSTRING");
        _encoderassetsStorageContainerName = _configuration.GetValue<string>("ENCODER_ASSETS_STORAGE_CONTAINER_NAME");

    }
    public async Task<string> UploadFileToBlobAsync(string strFileName, string contentType, Stream fileStream)
    {
        try
        {
            BlobContainerClient container = new BlobContainerClient(_encoderassetsStorageConnectionString, _encoderassetsStorageContainerName);
            BlobClient blobClient = container.GetBlobClient(strFileName);
            await blobClient.UploadAsync(fileStream, new BlobHttpHeaders { ContentType = contentType});
            var urlString = blobClient.Uri.ToString();
            return urlString;
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex.ToString());
            throw;
        }

    }


}
