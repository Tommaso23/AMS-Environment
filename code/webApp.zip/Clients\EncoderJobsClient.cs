﻿using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using BlazorStrap.Shared.InternalComponents;
using MediaServicesWebApp.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace MediaServicesWebApp.Clients;

public class EncoderJobsClient(HttpClient httpClient)
{   

    public async Task<List<CreatedJob>> GetEncoderJobsAsync()
        => await httpClient.GetFromJsonAsync<List<CreatedJob>>("api/encoderjobs") ?? new List<CreatedJob>();

    public async Task<CreatedJob> StartEncodingAsync(EncoderJob job)
    {
        var response = await httpClient.PostAsJsonAsync("api/encoderjobs/create?", job); 
        var jobResponse = await response.Content.ReadFromJsonAsync<CreatedJob>();

        return jobResponse;
    }

    public async Task<CreatedJob> GetCurrentJob(CreatedJob job)
    {
        var response = await httpClient.PostAsJsonAsync<CreatedJob>($"api/encoderJobs/getCurrentJob?", job);
        var jobResponse = await response.Content.ReadFromJsonAsync<CreatedJob>();

        return jobResponse;
    }
}

