﻿namespace MediaServicesWebApp;

public class FileUploadViewModel
{

    public required string FileName {get; set;}

    public required string FileStorageUrl {get; set;}

    public required string ContentType {get; set;}
}
