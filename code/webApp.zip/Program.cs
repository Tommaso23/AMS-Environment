using MediaServicesWebApp;
using MediaServicesWebApp.Clients;
using MediaServicesWebApp.Components;
using MediaServicesWebApp.Components.Layout;
using MediaServicesWebApp.Services.BlobStorageServices;
using Microsoft.AspNetCore.Mvc.ModelBinding.Binders;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddHttpClient();

builder.Services.AddBlazorBootstrap();

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();




var MediaServicesApiUrl = builder.Configuration["MediaServicesApiUrl"] ?? 
throw new Exception("MediaServicesApiUrl is not set");


builder.Services.AddHttpClient<EncoderPresetsClient>(client => client.BaseAddress = new Uri(MediaServicesApiUrl));
builder.Services.AddHttpClient<EncoderJobsClient>(client => client.BaseAddress = new Uri(MediaServicesApiUrl));
builder.Services.AddScoped<IBlobStorageService, BlobStorageService>();


var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
