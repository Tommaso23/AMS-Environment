﻿using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace MediaServicesWebApp.Models;

public class EncoderJob
{
    [Required]
    [StringLength(50)]
    public required string Name {get;set;}
    
    public required string Notes {get;set;}
    
    [Required]
    public required string FileName {get;set;}  
    
    [Required]
    public required string EncoderPresetId {get;set;}


    
}




