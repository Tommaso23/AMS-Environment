﻿namespace MediaServicesWebApp.Services.BlobStorageServices;

public interface IBlobStorageService
{
    Task<string> UploadFileToBlobAsync(string strFileName, string contentType, Stream fileStream);

}
