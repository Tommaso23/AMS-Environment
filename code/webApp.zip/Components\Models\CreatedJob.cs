﻿namespace MediaServicesWebApp;

public class CreatedJob
{
    public required string Id {get; set;}
    public required string Name {get;set;}
    public required string Preset {get;set;}
    public string? Notes {get; set;}
    public required string CdnEndpoint {get;set;}
    public required string FileName {get; set;}
    public required string Status {get; set;}

}
