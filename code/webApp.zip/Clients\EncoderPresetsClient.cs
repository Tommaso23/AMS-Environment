﻿using System.Text;
using MediaServicesWebApp.Models;

namespace MediaServicesWebApp.Clients;

public class EncoderPresetsClient(HttpClient httpClient)
{
    public async Task<List<EncoderPreset>> GetEncoderPresetsAsync() 
    => await httpClient.GetFromJsonAsync<List<EncoderPreset>>("api/encoderpresets") ?? new List<EncoderPreset>();

}
